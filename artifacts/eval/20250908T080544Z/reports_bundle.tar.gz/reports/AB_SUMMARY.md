# A/B Summary: LGBM vs ExtraTrees (2025-06-01..2025-08-31)

Artifacts directory: artifacts/eval/20250908T080544Z/reports/

Summary decision: DO NOT PROMOTE LGBM over ExtraTrees
Reasons:
- recent: log_loss worse by +0.018
- random: top1 worse by -0.075
- random: brier worse by +0.005
- random: log_loss worse by +0.020

## Metrics

- LGBM (recent)
  - races_evaluated: 200
  - top1_accuracy: 0.325
  - brier: 0.1258115850
  - log_loss: 0.4174669702

- LGBM (random)
  - races_evaluated: 200
  - top1_accuracy: 0.325
  - brier: 0.1254125809
  - log_loss: 0.4143892070

- ExtraTrees (recent)
  - races_evaluated: 200
  - top1_accuracy: 0.320
  - brier: 0.1216882002
  - log_loss: 0.3996199341

- ExtraTrees (random)
  - races_evaluated: 200
  - top1_accuracy: 0.400
  - brier: 0.1199502167
  - log_loss: 0.3941307385

## Deltas (LGBM - ExtraTrees)

- Recent:
  - top1_accuracy: +0.005
  - brier: +0.0041233848
  - log_loss: +0.0178470361

- Random:
  - top1_accuracy: -0.075
  - brier: +0.0054623642
  - log_loss: +0.0202584685

## Notes
- All runs used: module guard skipped, accuracy optimizer OFF, normalization mode=simple
- Date window filter applied at selection: 2025-06-01..2025-08-31 (completed races with winner)
- Verbose skip logs emitted to stderr during evaluation

## Next recommendations
- Keep ExtraTrees as the production baseline for this window.
- If pursuing LGBM improvements:
  - Align training feature set to current inference set (confirm TGR feature availability across training window).
  - Tune LGBM hyperparameters (learning_rate, num_leaves, min_data_in_leaf) and add stronger regularization.
  - Revisit calibration (isotonic/sigmoid) and ensure consistent categorical handling.
  - Re-run the same A/B window and confirm wins across both bands.

